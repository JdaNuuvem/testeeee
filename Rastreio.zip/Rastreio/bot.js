const { Client, GatewayIntentBits, ActionRowBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, InteractionType, EmbedBuilder } = require('discord.js');
const axios = require('axios');
const moment = require('moment-timezone');
const { HttpProxyAgent } = require('http-proxy-agent');
const { HttpsProxyAgent } = require('https-proxy-agent');
const fs = require('fs');
const path = require('path');

const client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent, GatewayIntentBits.GuildMembers] });

const token = 'MTI0NDIwNjA1NTg0ODgwODQ1OQ.GQkP_u.ZBk_WjKsvIdsh6Di6DNVvGQDE31fRpgyQbd-SE'; // Substitua pelo token do seu bot

const codesFilePath = path.join(__dirname, 'generated_codes.json');

function loadGeneratedCodes() {
    if (fs.existsSync(codesFilePath)) {
        const data = fs.readFileSync(codesFilePath, 'utf-8');
        if (data.trim().length === 0) {
            return {};
        }
        try {
            return JSON.parse(data);
        } catch (error) {
            console.error('Erro ao analisar o arquivo JSON:', error);
            return {};
        }
    }
    return {};
}

function saveGeneratedCodes(codes) {
    fs.writeFileSync(codesFilePath, JSON.stringify(codes, null, 2), 'utf-8');
}

const generatedCodes = loadGeneratedCodes();

class TrackingCodeGenerator {
    constructor(prefix, initialSerialNumber) {
        this.prefix = prefix;
        this.currentSerialNumber = initialSerialNumber;
        this.generatedCodes = new Set();
    }

    getCheckDigit(num) {
        const weights = [8, 6, 4, 2, 3, 5, 9, 7];
        const serialStr = String(num).padStart(8, '0');
        let sum = 0;
        for (let i = 0; i < serialStr.length; i++) {
            sum += weights[i] * parseInt(serialStr[i], 10);
        }
        sum = 11 - (sum % 11);
        if (sum === 10) sum = 0;
        else if (sum === 11) sum = 5;
        return sum;
    }

    generateTrackingCode() {
        this.currentSerialNumber++;
        const serialSuffix = String(this.currentSerialNumber).padStart(8, '0').slice(-4);
        const serialNumberStr = `${this.prefix}${serialSuffix}`;
        const checkDigit = this.getCheckDigit(serialNumberStr);
        const finalLetters = "BR";
        const trackingCode = `NM${serialNumberStr}${checkDigit}${finalLetters}`;
        return trackingCode;
    }

    generateMultipleTrackingCodes(quantity) {
        const codes = [];
        while (codes.length < quantity) {
            const newCode = this.generateTrackingCode();
            if (!this.generatedCodes.has(newCode)) {
                codes.push(newCode);
            }
        }
        return codes;
    }

    addToGenerated(code) {
        this.generatedCodes.add(code);
    }
}

function getProxyConfig() {
    return {
        host: 'f280b6c57513f186.shg.na.pyproxy.io',
        port: 16666,
        auth: {
            username: 'flashzxk29-zone-resi-region-br',
            password: 'flashzxk29'
        }
    };
}

function getProxyAgent() {
    const proxyConfig = getProxyConfig();
    const proxyUrl = `http://${proxyConfig.auth.username}:${proxyConfig.auth.password}@${proxyConfig.host}:${proxyConfig.port}`;
    return {
        http: new HttpProxyAgent(proxyUrl),
        https: new HttpsProxyAgent(proxyUrl)
    };
}

async function validateTrackingCodes(trackingCodes) {
    const codesStr = trackingCodes.join(',');
    const url = `https://global.cainiao.com/global/check.json?mailNos=${codesStr}&lang=en-US&language=en-US`;
    const headers = {
        Host: 'global.cainiao.com',
        Accept: 'application/json, text/plain, */*',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36',
        'Accept-Language': 'pt-BR,pt;q=0.9'
    };
    const proxyAgent = getProxyAgent();

    const maxRetries = 3;
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
        try {
            const response = await axios.get(url, { headers, httpAgent: proxyAgent.http, httpsAgent: proxyAgent.https });
            const data = response.data;
            const validCodes = data.module.filter(item => item.source === 'OTHER').map(item => item.mailNo);
            return validCodes;
        } catch (error) {
            console.error(`Error occurred on attempt ${attempt}:`, error.message);
            if (attempt === maxRetries) {
                console.error('Max retries reached. Unable to validate tracking codes.');
                return [];
            }
            await new Promise(res => setTimeout(res, 1000)); // Aguarde 1 segundo antes de tentar novamente
        }
    }
}

async function getTrackingCodeDetails(trackingCodes) {
    const codesStr = trackingCodes.join(',');
    const url = `https://global.cainiao.com/global/detail.json?mailNos=${codesStr}&lang=en-US&language=en-US`;
    const headers = {
        Host: 'global.cainiao.com',
        Accept: 'application/json, text/plain, */*',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36',
        'Accept-Language': 'pt-BR,pt;q=0.9'
    };
    const proxyAgent = getProxyAgent();

    const maxRetries = 3;
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
        try {
            const response = await axios.get(url, { headers, httpAgent: proxyAgent.http, httpsAgent: proxyAgent.https });
            return response.data;
        } catch (error) {
            console.error(`Error occurred on attempt ${attempt}:`, error.message);
            if (attempt === maxRetries) {
                console.error('Max retries reached. Unable to get tracking code details.');
                return null;
            }
            await new Promise(res => setTimeout(res, 1000)); // Aguarde 1 segundo antes de tentar novamente
        }
    }
}

function filterCodes(details, currentDateBrazil, currentDateChina) {
    if (!details || !details.module) return { validToday: [], sellerPreparing: [], departedFromWarehouse: [] };

    const validToday = [];
    const sellerPreparing = [];
    const departedFromWarehouse = [];

    for (const item of details.module) {
        if (item.detailList && item.detailList.length > 0) {
            for (const detail of item.detailList) {
                const eventDate = detail.timeStr;
                const eventDateOnly = eventDate.split(' ')[0]; // Apenas a data, sem a hora

                if (eventDateOnly === currentDateBrazil || eventDateOnly === currentDateChina) {
                    if (detail.standerdDesc === 'Shipment information received by warehouse electronically') {
                        validToday.push(item.mailNo);
                    }
                    if (detail.standerdDesc === 'Departed from warehouse') {
                        departedFromWarehouse.push(item.mailNo);
                    }
                }
            }
        }
        if (item.status === 'SELLER_PREPARING' && item.statusDesc === 'Awaiting seller dispatch' && (!item.detailList || item.detailList.length === 0)) {
            sellerPreparing.push(item.mailNo);
        }
    }

    console.log('validToday:', validToday);
    console.log('sellerPreparing:', sellerPreparing);
    console.log('departedFromWarehouse:', departedFromWarehouse);

    return { validToday, sellerPreparing, departedFromWarehouse };
}

client.once('ready', () => {
    console.log('Bot is online!');
});

client.on('interactionCreate', async interaction => {
    const allowedChannelId = '1244226933873709168';

    if (interaction.channelId !== allowedChannelId) {
        return interaction.reply({ content: 'Este comando só pode ser usado no canal específico.', ephemeral: true });
    }

    try {
        if (interaction.isCommand()) {
            const { commandName } = interaction;

            if (commandName === 'rastreio') {
                const modal = new ModalBuilder()
                    .setCustomId('inputModal')
                    .setTitle('Dados para Geração de Códigos de Rastreio');

                const textInput = new TextInputBuilder()
                    .setCustomId('inputText')
                    .setLabel('Digite a matriz do código de rastreio:')
                    .setStyle(TextInputStyle.Short);

                const quantityInput = new TextInputBuilder()
                    .setCustomId('inputQuantity')
                    .setLabel('Quantidade de códigos para gerar:')
                    .setStyle(TextInputStyle.Short);

                const actionRow1 = new ActionRowBuilder().addComponents(textInput);
                const actionRow2 = new ActionRowBuilder().addComponents(quantityInput);

                modal.addComponents(actionRow1, actionRow2);

                await interaction.showModal(modal);
            }
        } else if (interaction.isModalSubmit()) {
            if (interaction.customId === 'inputModal') {
                const inputText = interaction.fields.getTextInputValue('inputText');
                const inputQuantity = interaction.fields.getTextInputValue('inputQuantity');
                const matriz = inputText.trim();
                const quantidade = parseInt(inputQuantity, 10);

                const loadingEmbed = new EmbedBuilder()
                    .setDescription('🔄 Gerando códigos de rastreamento do dia de hoje...');

                await interaction.deferReply({ ephemeral: true });

                const prefix = matriz.slice(2, 6);
                const initialSerialNumber = parseInt(matriz.slice(6, 10), 10);

                const generator = new TrackingCodeGenerator(prefix, initialSerialNumber);
                const validTrackingCodes = [];

                const currentDateBrazil = moment().tz("America/Sao_Paulo").format('YYYY-MM-DD');
                const currentDateChina = moment().tz("Asia/Shanghai").format('YYYY-MM-DD');

                if (!generatedCodes[matriz]) {
                    generatedCodes[matriz] = [];
                }
                const alreadyGeneratedCodes = new Set(generatedCodes[matriz]);

                while (validTrackingCodes.length < quantidade) {
                    const newCodes = generator.generateMultipleTrackingCodes(100);
                    const validCodes = await validateTrackingCodes(newCodes);

                    if (validCodes.length === 0) continue;

                    const details = await getTrackingCodeDetails(validCodes);
                    const { validToday, sellerPreparing, departedFromWarehouse } = filterCodes(details, currentDateBrazil, currentDateChina);

                    for (const code of [...validToday, ...sellerPreparing, ...departedFromWarehouse]) {
                        if (validTrackingCodes.length < quantidade && !alreadyGeneratedCodes.has(code)) {
                            generator.addToGenerated(code);
                            validTrackingCodes.push(code);
                            alreadyGeneratedCodes.add(code);
                        }
                    }
                }

                generatedCodes[matriz] = Array.from(alreadyGeneratedCodes);
                saveGeneratedCodes(generatedCodes);

                let responseMessage = 'Códigos de rastreamento válidos gerados:\n\n';
                for (const code of validTrackingCodes) {
                    responseMessage += `${code}\n`;
                }

                await interaction.editReply({ content: `\`\`\`${responseMessage}\`\`\``, embeds: [] });
            }
        }
    } catch (error) {
        console.error('Erro ao processar a interação:', error);
        if (interaction.deferred || interaction.replied) {
            await interaction.editReply({ content: 'Ocorreu um erro ao processar sua solicitação.', embeds: [] });
        } else {
            await interaction.reply({ content: 'Ocorreu um erro ao processar sua solicitação.', ephemeral: true });
        }
    }
});

client.on('ready', async () => {
    const guild = client.guilds.cache.get('1240858169798824017');
    let commands;

    if (guild) {
        commands = guild.commands;
    } else {
        commands = client.application.commands;
    }

    await commands.create({
        name: 'rastreio',
        description: 'Abra um modal para inserir a matriz e a quantidade de códigos de rastreio'
    });
});

client.login(token);

process.on('unhandledRejection', error => {
    console.error('Unhandled promise rejection:', error);
});

process.on('uncaughtException', error => {
    console.error('Uncaught exception:', error);
});
